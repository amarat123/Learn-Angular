import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogpost-featured',
  templateUrl: './blogpost-featured.component.html',
  styleUrls: ['./blogpost-featured.component.css']
})
export class BlogpostFeaturedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
