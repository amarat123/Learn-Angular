import { Blogpost } from './blogpost';

describe('Blogpost', () => {
  it('should create an instance', () => {
    expect(new Blogpost()).toBeTruthy();
  });
});
